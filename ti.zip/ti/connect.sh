#!/bin/bash
ssh armycert@10.1.11.121 -p 20022
