import telegram
import requests
import difflib
import asyncio
import urllib3
import signal
import time
from operator import itemgetter
from datetime import datetime
from pyppeteer import launch

urllib3.disable_warnings()

global zrr_list
zrr_list = []

my_token = '5393744135:AAHTsdpYaAo7wqdTHK56Ci1gUBn2WZ1oEBA'
bot = telegram.Bot(token = my_token)
asyncio.run(bot.getUpdates())
group_chatid = -811558305

badurl=['coin','zum','nate','sisajournal','byline','block','token']
goodurl=['boan','newsis','mk.co.kr','sedaily','nkeconomy','hankyung','donga','chosun','joongang.','munhwa','seoul.co.kr','yna.co.kr']
primeurl=['boan','cctvnews','etnews','ddaily','ahnlab','itworld','zdnet','dailysecu','koit.co.kr']
exelenturl=['dailynk','rfa.org','voakorea']
nogoodwords=['가상자산','암호화폐','코인','블록체인']
badwords=['솔루션','출시','IPO','상장','해커톤']
keyword_north = ['북 ', '북한', '北']
keyword_main = ['해킹','악성코드','랜섬웨어','스미싱','apt공격']
keyword_sub = ['취약점','피싱','치명적']
news_list = []
key_news = []
similar_matrix = []
score_list = []
for i in range(500):
    similar_matrix.append([])
    for j in range(500):
        similar_matrix[i].append(0.0)

class news():
    def __init__(self, href='', src='', headline='', contents='', timeline=''):
        self.href = href
        self.src = src
        self.headline = headline
        self.contents = contents
        self.timeline = timeline

def request_nws(keyword):
    res = requests.get('https://www.google.com/search', params={'q':keyword, 'tbm':'nws', 'tbs':'qdr:d', 'start':'0'}, headers={"User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0"})
    target = res.text
    aaaa=0
    while True:
        # NEWS OUTLINE START
        _pstr = 'class=\"SoaBEf'
        if target.find(_pstr) == -1:
            break
        target = target[target.find(_pstr)+len(_pstr):]
        _nws = news()
        aaaa+=1
        # PARSE NEWS HREF
        _pstr = 'class=\"WlydOe\"'
        target = target[target.find(_pstr)+len(_pstr):]
        _pstr = 'href=\"'
        target = target[target.find(_pstr)+len(_pstr):]
        _nws.href = target[:target.find('\"')]       

        # PARSE NEWS SOURCE 
        _pstr = 'class=\"CEMjEf NUnG9d\"'
        target = target[target.find(_pstr)+len(_pstr):]
        _pstr = '<span>'
        target = target[target.find(_pstr)+len(_pstr):]
        _nws.src = target[:target.find('</span>')]

        # PARSE NEWS HEADLINE
        _pstr = 'class=\"mCBkyc ynAwRc MBeuO nDgy9d\"'
        target = target[target.find(_pstr)+len(_pstr):]
        _pstr = '>'
        target = target[target.find(_pstr)+len(_pstr):]
        _nws.headline = target[:target.find('</div>')]

        # PARSE NEWS CONTENTS
        _pstr = 'class=\"GI74Re jBgGLd OSrXXb\"'
        target = target[target.find(_pstr)+len(_pstr):]
        _pstr = '>'
        target = target[target.find(_pstr)+len(_pstr):]
        _nws.contents = target[:target.find('</div>')]

        # PARSE NEWS TIMELINE
        _pstr = 'class=\"OSrXXb ZE0LJd YsWzw\"'
        target = target[target.find(_pstr)+len(_pstr):]
        _pstr = '<span>'
        target = target[target.find(_pstr)+len(_pstr):]
        _nws.timeline = target[:target.find('</span>')]
        # ADD TO LIST EXCEPT SIMILAR
        check = True
        _i = 0
        for nn in news_list:
            for badnews in badurl:
                if badnews in _nws.href:
                    check=False
                    break

            if check_sim(nn.headline, _nws.headline) >= 0.45:
                print('[-] similar news discard.')
                check = False
                break
            _i += 1
        if check:
            news_list.append(_nws)         

def checkurl(href):
    for url in badurl:
        if url in href:
            return -1

def print_news(nns):
    for nws in nns:
        print('--------------------')
        print('href     : {}'.format(nws.href))
        print('src      : {}'.format(nws.src))
        print('headline : {}'.format(nws.headline.replace('<br>','')))
        print('contents : {}'.format(nws.contents.replace('<br>','')))
        print('timeline : {}'.format(nws.timeline))

def convert_zrr(url):
    payload = {}
    payload['url'] = url
    if url.find('https://') < 0 and url.find('http://') < 0:
        url = 'https://' + url
    res = requests.post('https://zrr.kr/create_url.php', data=payload)
    return 'https://zrr.kr/'+res.text

def alarm_handler(signum, frame):
    print('[-] Browser Execution timeout.')
    raise TimeOutException()

async def convert_zrr_append(key_news):
    global zrr_list

    for i in range(len(key_news)):
        news = key_news[i]
        cnt = 0
        browser = None
        browser = await launch(dumpio=True, args=['--no-sandbox', '--disable-dev-shm-usage','--disable-gpu'])
        s = requests.Session()
        while True:
            signal.signal(signal.SIGALRM, alarm_handler)
            signal.alarm(60)
            try:
                page = await browser.newPage()
                await page.goto('https://zrr.kr')  # Replace with your website URL
                await page.evaluate('''const token = grecaptcha.enterprise.execute(\'6LdVOt8nAAAAAPs4BePzyRSjSmFxSQamig82DFC4\', { action: \'submit\' });''')
                token = await page.evaluate('token')
                print(token)
        
                payload = {}
                payload['url'] = news.href
                payload['token'] = token
                
                res = s.post('https://zrr.kr/create_url.php', data=payload, verify='/etc/ssl/certs')
                if res.text.lower().find('recaptcha') != -1 or res.text.lower().find('err') != -1 or len(res.text.strip()) == 0:
                    zrr_list.append(news.href)
                    print('[-] error while requesting url')
                    print('[+] just continue its original url.')
                    break
                zrr_list.append('https://zrr.kr/'+res.text)
                print('{}\n{}'.format(news.href, 'https://zrr.kr/'+res.text))
                break
            except Exception as ex:
                print(ex)
                print('[-] error while process asyncio. restart from current status.')
                time.sleep(20)
                continue
            finally:
                signal.alarm(0) # reset timeout
                if browser != None:
                    await browser.close()
                time.sleep(2)

def crawl_news():
    for head in keyword_north:
        for mid in keyword_main:
            request_nws(head + ' ' + mid) 
            print('head process....')

    for mid in keyword_main:
            request_nws(mid)
            print('mid processss')

    for mid in keyword_main:
        for tail in keyword_sub:
            request_nws(mid + ' ' + tail) 
            print('tail processss...')

def check_sim(s1, s2):
    s1_bytes = bytes(s1, 'utf-8')
    s2_bytes = bytes(s2, 'utf-8')
    s1_bytes_list = list(s1_bytes)
    s2_bytes_list = list(s2_bytes)
    sm = difflib.SequenceMatcher(None, s1_bytes_list, s2_bytes_list)
    similar = sm.ratio()
    return similar

#################################################################################
#################################################################################
#################################################################################

def extract_key_news():
    for i in range(len(news_list)):
        cyberscore=0
        news_list[i].headline=news_list[i].headline.replace('<br>',' ')
        news_list[i].contents=news_list[i].contents.replace('<br>','')
        print(news_list[i].headline+'언론사:'+news_list[i].src)
        for mkeyword in keyword_main:
            if mkeyword in news_list[i].contents:
                cyberscore += 1.5

            if mkeyword in news_list[i].headline:
                cyberscore += 2.5

        for skeyword in keyword_sub:
            if skeyword in news_list[i].contents:
                cyberscore += 0.5
            if skeyword in news_list[i].headline:
                cyberscore += 1.5
                #print(skeyword+'!!!!!@subhead!!!!!!!')
        for nogoodword in nogoodwords:
            if nogoodword in news_list[i].headline:
                cyberscore -= 1.5
        for badword in badwords:
            if badword in news_list[i].headline:
                cyberscore -= 4
        for goodnews in goodurl:
            if goodnews in news_list[i].href:
                cyberscore += 1       

        ##고점가중방식        
        for primenews in primeurl:
            if primenews in news_list[i].href:
                if cyberscore > 4:
                    cyberscore += 5
                else:
                    cyberscore += 2
        for exelentnews in exelenturl:                
            if exelentnews in news_list[i].href:
                if cyberscore > 3 :
                    if check_north:
                        cyberscore += 10
                    else:
                        cyberscore += 2
                else:
                    cyberscore += 1
       # print('--------------------')
       # print(news_list[i].headline)
       # print(cyberscore)
       # print('--------------------')
        score_list.append((cyberscore,i))
    score_list.sort(key=itemgetter(0), reverse=True)
    i = 0
    print(len(score_list))
    for avg, idx in score_list:
        if avg <3:
            break
        if i >= 15:
            break
        print(avg, idx)
        print(news_list[idx].headline)
        print(news_list[idx].src)
        key_news.append(news_list[idx])
        i += 1
    print(str(i)+'개 최종선정되었습니다')

def check_north(news):
    for keyword in keyword_north:
        if news.headline.find(keyword) != -1:
            return True
    return False

def create_telegram_msg():
    global zrr_list

    msg = ''
    day = ['월', '화', '수', '목', '금', '토', '일']
    now = datetime.now()
    msg += now.strftime('%m.%d.')
    msg += ' ({}), '.format(day[now.weekday()])
    msg += '사이버 언론기사입니다.'
    i = 0
    for news in key_news:
        msg += '\n\n'
        if check_north(news):
            msg += '[북관련]\n'
        else:
            msg += '[국내외]\n'
        msg += '{} {}({})\n'.format(chr(9312+i), news.headline, news.src)
        #msg += convert_zrr(news.href)
        msg += zrr_list[i]
        #msg += chr(8594) + ' 참고'
        i += 1
    return msg

crawl_news()
extract_key_news()
print_news(key_news)
asyncio.run(convert_zrr_append(key_news))
asyncio.run(bot.sendMessage(chat_id = group_chatid, text=create_telegram_msg()))
