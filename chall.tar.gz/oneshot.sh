#!/bin/bash
cd rootfs
gcc -o ex ex.c --static -masm=intel
./gen_cpio.sh ../rootfs.cpio
cd ..
./start.sh
