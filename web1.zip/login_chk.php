<?php
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$mysqli = mysqli_connect("localhost", "root", "TEST", "gallery");

$check = "SELECT * FROM member WHERE name='$username' and password='$password'";
$result = $mysqli->query($check);

if ( $result->num_rows >= 1 )
{
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $_SESSION['userid'] = $username;
        if ( isset($_SESSION['userid']) )
        {
                $name = $row['name'];
                $age = $row['age'];
                $description = $row['description'];
                echo "<p>$name</p>";
                echo "<p>$age</p>";
                echo "<p>$description</p>";
                header ('Location: ./index.php?name='.$name.'?age='.$age.'?description='.$description.'');
        }
        else
        {
                echo "ERROR.";
        }
}
else
{
        echo "Wrong Username or Password";
}
?>
