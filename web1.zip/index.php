<?php
session_start();
if ( !isset($_SESSION['userid']) )
{
        header ('Location: ./login.html');
}
echo "<p>login success</p>";
echo "<a href=logout.php>logout</a>";
?>