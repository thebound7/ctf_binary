function draw_barchart(svg, file_list, size_list)
{
	var margin = {top: 20, right: 20, bottom: 70, left: 40},
	    width = 600 - margin.left - margin.right,
	    height = 300 - margin.top - margin.bottom;

	// Parse the date / time
	var parseDate = d3.time.format("%Y-%m").parse;

	var x = d3.scale.ordinal().rangeRoundBands([0, width], .05);

	var y = d3.scale.linear().range([height, 0]);

	var xAxis = d3.svg.axis()
	    .scale(x)
	    .orient("bottom");
	    //.tickFormat(d3.time.format("%s"));

	var yAxis = d3.svg.axis()
	    .scale(y)
	    .orient("left")
	    .ticks(10);

	var pos_x = 850;
	var pos_y = 225;

	data = new Array();
	var start = 0;
	if ( size_list.length > 14 )
		start = size_list.length - 14;
	for ( var i = start; i < size_list.length; i++ )
	{
		if ( size_list[i] < 4096 )
		{
			jfile = new Object();
			jfile.name = file_list[i];
			jfile.size = size_list[i];
			data.push(jfile);
		}
	}
	    data.forEach(function(d) {
		d.name = d.name;
		d.size = +d.size;
	    });
		
	  x.domain(data.map(function(d) { return d.name; }));
	  y.domain([0, d3.max(data, function(d) { return d.size; })]);

	  svg.append("g")
	      .attr("class", "x axis")
	      .attr("fill", "white")
	      .attr("transform", "translate("+pos_x+"," + (height+pos_y) + ")")
	      .call(xAxis)
	    .selectAll("text")
	      .style("text-anchor", "end")
	      .attr("fill", "white")
	      .attr("dx", "-.8em")
	      .attr("dy", "-.55em")
	      .attr("transform", "rotate(-90)" );

	  svg.append("g")
	      .attr("class", "y axis")
	      .attr("fill", "white")
	      .attr("transform", "translate("+(pos_x)+","+(pos_y+6)+")")
	      .call(yAxis)
	    .append("text")
	      .attr("fill", "white")
	      .attr("dy", "-3.50em")
	      .style("text-anchor", "end")
	      .attr("transform", "rotate(-90)")
	      .text("Traffic (bytes)");

	  svg.selectAll("bar")
	      .data(data)
	    .enter().append("rect")
	      .style("fill", "red")
	      .attr("x", function(d) { return x(d.name)+pos_x; })
	      .attr("width", x.rangeBand())
	      .attr("y", function(d) { return y(d.size)+pos_y; })
	      .attr("height", function(d) { return height - y(d.size); });

}
