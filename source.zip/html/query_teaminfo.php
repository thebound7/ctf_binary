<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'toor', 'ctfv');
if ( $mysqli->connect_errno )
{
	echo "error while loading database.";
	exit;
}

$sql = "select * from team order by tscore desc";
if ( !$result = $mysqli->query( $sql ) )
{
	echo "error while querying team information.";
	exit;
}

if ( $result->num_rows === 0 )
{
	echo "there are no team information.";
	exit;
}

$team_array = array();
while ( $team = $result->fetch_assoc() )
{
	$cur_team = array(
		"tname"=>$team['tname'], 
		"tdescription"=>$team['tdescription'],
		"tscore"=>$team['tscore'], 
		"tsolve"=>$team['tsolve'], 
		"timgpath"=>$team['timgpath'], 
		"tport"=>$team['tport'], 
		"tccode"=>$team['tccode']
	);
	array_push($team_array, $cur_team);
}
header('Content-Type: application/json');
echo json_encode($team_array);
?>
