<?php
$file_list = scandir("./packets/1/");
$output = shell_exec("ls ./packets/1 | wc -l ");
$size_list = [];
$real_file_list = [];

sort($file_list);
for ( $i = 0; $i < count($file_list); $i++ )
{
	if ( filesize( "./packets/1/".$file_list[$i]) < 4000 )
	{
		array_push($size_list, filesize( "./packets/1/".$file_list[$i] ));
		array_push($real_file_list, $file_list[$i]);
	}	
}
$cnt = (int)$output;

echo "<script>";
echo "var cnt_logged = ".$cnt.";";
echo "var file_list = ".json_encode($real_file_list).";";
echo "var size_list = ".json_encode($size_list).";";
echo "</script>";

?>

<!DOCTYPE html>
<meta charset="utf-8">
<body>
<script src="//d3js.org/d3.v3.min.js"></script>
<script src="/team_chart.js"></script>
<script>
var width = 1500, height = 700;
var svg = d3.select("body").append("svg")
            .attr("width", width)
            .attr("height", height)
            .style("background-color", "black");

var array_max = size_list.reduce( function (previous, current) {
	return previous > current ? previous:current;
});
var circle_size = array_max/32;

var nodes = d3.range(cnt_logged+1).map(function(i) { return {radius: size_list[i]/circle_size}; }),
    root = nodes[0],
    color = d3.scale.category10();

root.radius = 0;
root.fixed = true;
var force = d3.layout.force()
    .gravity(0.05)
    .charge(function(d, i) { return i ? 0 : -2000; })
    .nodes(nodes)
    .size([width-600, height]);

force.start();
svg.selectAll("circle")
    .data(nodes.slice(1))
  .enter().append("circle")
    .attr("r", function(d) { return d.radius; })
    .style("fill", function(d, i) { return color(i % 3); });

force.on("tick", function(e) {
  var q = d3.geom.quadtree(nodes),
      i = 0,
      n = nodes.length;

  while (++i < n) q.visit(collide(nodes[i]));

  svg.selectAll("circle")
      .attr("cx", function(d) { return d.x; })
      .attr("cy", function(d) { return d.y; });
});
svg.on("mousemove", function() {
  var p1 = d3.mouse(this);
  root.px = p1[0];
  root.py = p1[1];
  force.resume();
});

function collide(node) {
  var r = node.radius + 16,
      nx1 = node.x - r,
      nx2 = node.x + r,
      ny1 = node.y - r,
      ny2 = node.y + r;
  return function(quad, x1, y1, x2, y2) {
    if (quad.point && (quad.point !== node)) {
      var x = node.x - quad.point.x,
	  y = node.y - quad.point.y,
	  l = Math.sqrt(x * x + y * y),
	  r = node.radius + quad.point.radius;
      if (l < r) {
	l = (l - r) / l * .5;
	node.x -= x *= l;
	node.y -= y *= l;
	quad.point.x += x;
	quad.point.y += y;
      }
    }
    return x1 > nx2 || x2 < nx1 || y1 > ny2 || y2 < ny1;
  };
}
draw_barchart(svg, file_list, size_list);
var activity_text = svg.append("text")
	.attr("x", 250)
	.attr("y", 80)
	.attr("fill", "white")
	.style("font-size", "50px")
	.text("Team Activity");
var status_text = svg.append("text")
	.attr("x", 1000)
	.attr("y", 80)
	.attr("fill", "white")
	.style("font-size", "50px")
	.text("Timeline");
</script>
