function draw_map()
{
	var pos_x = new Array();
	var pos_y = new Array();
	var x;
	var y;
	var team_num = 8;
	var r = 130;
	var theta = 360/team_num;
	var i = 1;
	var j = 1;
	var map = canvas.append("circle")
		.attr("stroke","white")
		.attr("fill","transparent")
		.attr("cx",200)
		.attr("cy",550)
		.attr("r",130);
	for ( i = 1 ; i <= team_num;i++){
		var radians = (theta*i) * (Math.PI/180);
		x = (Math.sin(radians)*r)+200;
		pos_x[i] = x;
		y = (Math.cos(radians)*r)+550;
		pos_y[i] = y;
		canvas.append("circle")
		.attr("type","button")
		.attr("stroke",team_color[i])
		.attr("stroke-width",6)
		.attr("fill",team_color[i])
		.attr("cx",x)
		.attr("cy",y)
		.attr("r",15)
		.on("mouseover",function(d) {
			d3.select(this)
		.style("cursor","pointer");
		})
		.on("mouseout",function(d){
			d3.select(this)
			.style("cursor","default");
			
		})
		.on("click",function(d) {
			d3.select(this)
			.attr("onclick", "location.href='http://35.238.139.0/ji/index2.html'");
		});
	
	}
/*
	function line(x1,x2) {
		var line = canvas.append("line")
			.style("stroke", team_color[x1])
			.style("stroke-width", 2)
			.style("stroke-dasharray", ("5, 5"))
			.attr("x1", pos_x[x1])
			.attr("y1", pos_y[x1])
			.attr("x2", pos_x[x1])
			.attr("y2", pos_y[x1]);

		line.transition()
			.duration(1000)
			.attr("x1", pos_x[x1])
			.attr("y1", pos_y[x1])
			.attr("x2", pos_x[x2])
			.attr("y2", pos_y[x2]);
			
		line.transition().delay(2000).duration(2000)
			.remove();
	}

	function mov_image(x1,x2) {
		var image = canvas.append("image")
		.attr("xlink:href", "ufo.png")
		.attr("width", 30)
		.attr("height", 30)
		.attr("x", pos_x[x1]-15)
		.attr("y", pos_y[x1]-15)
		.transition().duration(1000)
		.attr("x", pos_x[x2]-15)
		.attr("y", pos_y[x2]-15);
	image.transition().delay(2000)
		.remove();
	}
*/

	//line(6,2);
	//mov_image(6,2);
}
