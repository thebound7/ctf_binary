function start_globe()
{
	var config = {
		speed: 0.005,
		verticalTilt: -30,
		horizontalTilt: 0
	}
	let locations = [];
	let countries = [];
	var markerGroup = canvas.append('g');
	var projection = d3.geoOrthographic();
	var initialScale = projection.scale();
	var path = d3.geoPath().projection(projection);
	var center = [400, 200];
	var global_time;
	var drag = d3.drag()
		.on("start", dragstarted)
		.on("drag", dragged)
		.on("end", dragended);
	var tmp = canvas.append("circle")
		.attr("stroke","#00248f")
		.attr("stroke-width",1)
		.attr("cx",680)
		.attr("cy",350)
		.attr("r",252)
		.attr("fill", "#00248f");
	drawGlobe();
	drawGraticule();
	enableRotation();
	//canvas.call(drag);

	function drawGlobe() {
		d3.queue()
			.defer(d3.json, 'world-110m.json')
			.defer(d3.json, 'locations.json')
			.defer(d3.json, 'country-code.json')
				.await((error, worldData, locationData, countryCode) => {
					canvas.selectAll(".segment")
					.data(topojson.feature(worldData, worldData.objects.countries).features)
					.enter().append("path")
					.attr("class", "segment")
					.attr("d", path)
					.attr("transform", "translate(200,100)")
					.style("stroke", "black")
					.style("stroke-width", "1px")
					.style("fill", (d, i) => '#a98b6f')
					.style("opacity", "1")
					//.call(d3.zoom().on("zoom", function () {
					//canvas.attr("transform", d3.event.transform)}))
					.call(drag);
					//.attr('type', 'button')
					//.on('click', changeRotation);
				//locations = locationData;
				countries = countryCode.ref_country_codes;
				country_cnt = countries.length;
				for ( var i = 0; i < 8; i++ )
				{
					var jsonCountry = new Object();
					for ( var j = 0; j < country_cnt; j++ )
					{
						if ( countries[j].alpha3.toUpperCase() == team_array[i].tccode.toUpperCase() )
						{
							jsonCountry.latitude = countries[j].latitude;
							jsonCountry.longitude = countries[j].longitude;
							jsonCountry.tidx = team_array[i].tidx;
							break;
						}
					}
					locations.push(jsonCountry);
				}
				airfly([countries[0].latitude, countries[0].longitude], [countries[1].latitude, countries[1].longitude]);
				drawMarkers();
		});
	}

	function drawGraticule() {
		var graticule = d3.geoGraticule();

		canvas.append("path")
			.datum(graticule)
			.attr("class", "graticule")
			.attr("d", path)
			.attr("transform", "translate(200,100)")
			.style("fill", "#00248f")
			.style("stroke", "skyblue")
			.style("opacity", "1")
			//.attr('type', 'button')
			//.call(d3.zoom().on("zoom", function () {
			//canvas.attr("transform", d3.event.transform)}))
			.call(drag);
			//.on('click', changeRotation);
	}

	function enableRotation() {
		rot = true;
		rot_timer = d3.interval(function (elapsed) {
			projection.rotate([config.speed * elapsed - 120, config.verticalTilt, config.horizontalTilt]);
			canvas.selectAll(".graticule").attr("d", path);
			canvas.selectAll(".segment").attr("d", path);
			//svg.selectAll("path").attr("d", path);
			drawMarkers();
			global_time = elapsed;
		}, 0);
	}

	function changeRotation()
	{
		if ( rot == true )
		{
			rot = false;
			rot_timer.stop();
		}
		else
		{
			rot = true;
			rot_timer.restart(function (elapsed) {
				projection.rotate([config.speed * elapsed - 120, config.verticalTilt, config.horizontalTilt]);
				canvas.selectAll(".graticule").attr("d", path);
				canvas.selectAll(".segment").attr("d", path);
				//svg.selectAll("path").attr("d", path);
				drawMarkers();
				global_time = elpased;
			}, 0, global_time);
		}
	}

	function clicked()
	{
		location.href='http://35.238.139.0/team_info.php';
	}

	function drawMarkers() {
		var markers = markerGroup.selectAll('circle')
			.data(locations);
		markers
			.enter()
			.append('circle')
			.attr("transform", "translate(200,100)")
			.attr('type', 'button')
			.merge(markers)
			.attr('cx', d => projection([d.longitude, d.latitude])[0])
			.attr('cy', d => projection([d.longitude, d.latitude])[1])
			.attr('fill', d => {
				var coordinate = [d.longitude, d.latitude];
				gdistance = d3.geoDistance(coordinate, projection.invert(center));
				return gdistance > 1.57 ? 'none' : team_color[d.tidx+1];
			})
			.attr('r', 7)
                        .on('click', clicked);

		markerGroup.each(function () {
			this.parentNode.appendChild(this);
		});
	}

	function dragstarted() 
	{
		changeRotation();
		v0 = versor.cartesian(projection.invert(d3.mouse(this)));
		r0 = projection.rotate();
		q0 = versor(r0);
	}

	function dragged() {
		var v1 = versor.cartesian(projection.rotate(r0).invert(d3.mouse(this))),
		q1 = versor.multiply(q0, versor.delta(v0, v1)),
		r1 = versor.rotation(q1);
		projection.rotate(r1);
		canvas.selectAll(".graticule").attr("d", path);
		canvas.selectAll(".segment").attr("d", path);;
		drawMarkers();
	}

	function dragended()
	{
		//changeRotation();
	}

	//interpolator from http://bl.ocks.org/jasondavies/4183701
	var d3_geo_greatArcInterpolator = function() {
	    var d3_radians = Math.PI / 180;
	    var x0, y0, cy0, sy0, kx0, ky0,
		x1, y1, cy1, sy1, kx1, ky1,
		d,
		k;

	    function interpolate(t) {
		var B = Math.sin(t *= d) * k,
		    A = Math.sin(d - t) * k,
		    x = A * kx0 + B * kx1,
		    y = A * ky0 + B * ky1,
		    z = A * sy0 + B * sy1;
		return [
		    Math.atan2(y, x) / d3_radians,
		    Math.atan2(z, Math.sqrt(x * x + y * y)) / d3_radians
		];
	    }

	    interpolate.distance = function() {
		if (d == null) k = 1 / Math.sin(d = Math.acos(Math.max(-1, Math.min(1, sy0 * sy1 + cy0 * cy1 * Math.cos(x1 - x0)))));
		return d;
	    };

	    interpolate.source = function(_) {
		var cx0 = Math.cos(x0 = _[0] * d3_radians),
		    sx0 = Math.sin(x0);
		cy0 = Math.cos(y0 = _[1] * d3_radians);
		sy0 = Math.sin(y0);
		kx0 = cy0 * cx0;
		ky0 = cy0 * sx0;
		d = null;
		return interpolate;
	    };

	    interpolate.target = function(_) {
		var cx1 = Math.cos(x1 = _[0] * d3_radians),
		    sx1 = Math.sin(x1);
		cy1 = Math.cos(y1 = _[1] * d3_radians);
		sy1 = Math.sin(y1);
		kx1 = cy1 * cx1;
		ky1 = cy1 * sx1;
		d = null;
		return interpolate;
	    };

	    return interpolate;
	}

	function airfly(startGeom, endGeom)
	{
		var journey = [];
		journey[0] = startGeom[0];
		journey[1] = endGeom[0];
		var n = countries.length;
		var startCoord = d3.geoCentroid(journey[0]),
		endCoord = d3.geoCentroid(journey[1])
		var coords = [-startCoord[0], -startCoord[1]]
		
		var flightPath ={}
		flightPath.type = "LineString";
		flightPath.coordinates = [startCoord, endCoord];

		var plane = document.getElementById('plane');
		customTransition(journey)

		function redraw3(flightPath, angle, planeSize){
			var pt = projection.rotate();
			var planeCartesianCoord = projection([-pt[0], -pt[1], 0]);
			//c.clearRect(0, 0, width, height);
			/*
			c.shadowBlur = 0, c.shadowOffsetX = 0, c.shadowOffsetY = 0;
			c.fillStyle = seaFill, c.beginPath(), path(globe), c.fill();
			c.fillStyle = landFill, c.beginPath(), path(land), c.fill();
			c.fillStyle = selectedCountryFill, c.beginPath(), path(journey[0]), c.fill();
			c.fillStyle = selectedCountryFill, c.beginPath(), path(journey[1]), c.fill();
			c.strokeStyle = flightPathColor, c.lineWidth = 3, c.setLineDash([10, 10])
			    c.beginPath(), path(flightPath),
			    //c.shadowColor = "#373633",
			    //c.shadowBlur = 20, c.shadowOffsetX = 5, c.shadowOffsetY = 20,
			    c.stroke();
			*/
			drawPlane(plane, planeCartesianCoord[0], planeCartesianCoord[1], angle, planeSize,planeSize)
		
		}

		//make the plane always align with the direction of travel
		function calcAngle(originalRotate, newRotate){
			var deltaX = newRotate[0] - originalRotate[0],
			    deltaY = newRotate[1] - originalRotate[1]

			return Math.atan2(deltaY, deltaX);
		}

		//this is to make the globe rotate and the plane fly along the path
		function customTransition(journey){
			var rotateFunc = d3_geo_greatArcInterpolator();
			d3.transition()
		    .delay(250)
		    .duration(5050)
		    .tween("rotate", function() {
			var point = d3.geoCentroid(journey[1]);
			rotateFunc.source(projection.rotate()).target([-point[0], -point[1]]).distance();
			var pathInterpolate = d3.geoInterpolate(projection.rotate(), [-point[0], -point[1]]);
			var oldPath = startCoord;
			    return function (t) {
				projection.rotate(rotateFunc(t));
				var newPath = [-pathInterpolate(t)[0], -pathInterpolate(t)[1]];
				var planeAngle = calcAngle(projection(oldPath), projection(newPath));
				var flightPathDynamic = {}
				flightPathDynamic.type = "LineString";
				flightPathDynamic.coordinates = [startCoord, [-pathInterpolate(t)[0], -pathInterpolate(t)[1]]];
				var maxPlaneSize =  0.1 * projection.scale();
				//this makes the plane grows and shrinks at the takeoff, landing
				if (t <0.1){
				    redraw3(flightPathDynamic, planeAngle, Math.pow(t/0.1, 0.5) * maxPlaneSize);
				}else if(t > 0.9){
				    redraw3(flightPathDynamic, planeAngle, Math.pow((1-t)/0.1, 0.5) * maxPlaneSize );
				}else{
				    redraw3(flightPathDynamic, planeAngle, maxPlaneSize);
				}
				//redraw3(flightPathDynamic, (planeAngle))
			    };
			//}
		    }).each("end", function(){
			//make the plane disappears after it's reached the destination
			//also enable the drag interaction at this point
			//redraw();
			d3.select("#globeParent").select('canvas').call(dragBehaviour);
			document.write("ffffffff");
		    })
		}

		//add the plane to the canvas and rotate it
		function drawPlane(image, xPos, yPos, angleInRad, imageWidth, imageHeight){
			/*
			context.translate(xPos, yPos);
			// rotate around that point, converting our
			// angle from degrees to radians
			context.rotate(angleInRad);
			// draw it up and to the left by half the width
			// and height of the image, plus add some shadow
			//context.shadowColor = "#373633", context.shadowBlur = 20, context.shadowOffsetX = 5, context.shadowOffsetY = 10;
			context.drawImage(image, -(imageWidth/2), -(imageHeight/2), imageWidth, imageHeight);

			// and restore the co-ords to how they were when we began
			context.restore();*/
		}
	}
}
