<?php
	$mysqli = new mysqli('127.0.0.1', 'root', 'toor', 'ctfv');	
	if ( $mysqli->connect_errno )
	{
		echo "error while loading database.";
		exit;
	}

	$sql = "select * from team order by tscore desc";
	if ( !$result = $mysqli->query( $sql ) )
	{
		echo "error while querying team information.";
		exit;
	}

	if ( $result->num_rows === 0 )
	{
		echo "there are no team information.";
		exit;
	}

	echo "<script type=\"text/javascript\">";
	echo "var team_array = new Array();";
	echo "var after_team_array = new Array();";
	while ( $team = $result->fetch_assoc() )
	{
		echo "var cur_team = new Object();";
		echo "cur_team.tname = \"".$team['tname']."\";";
		echo "cur_team.tdescription = \"".$team['tdescription']."\";";
		echo "cur_team.tscore = \"".$team['tscore']."\";";
		echo "cur_team.tsolve = \"".$team['tsolve']."\";";
		echo "cur_team.timgpath = \"".$team['timgpath']."\";";
		echo "cur_team.tport = ".$team['tport'].";";
		echo "cur_team.tccode = \"".$team['tccode']."\";";
		echo "team_array.push(cur_team);";
		echo "after_team_array.push(cur_team);";
	}
	echo "var teams = JSON.stringify(team_array);";
	echo "</script>";
?>

<!DOCTYPE html>
<html>
<p></p>
<style>
rect
{
	fill:white;
	stroke:black;
}
text
{
	font-size:16px;
	font-weight:bold;
	fill:white;
}
</style>
<head>
	<script type="text/javascript" src="https://d3js.org/d3.v4.min.js"></script>
        <script type="text/javascript" src="https://d3js.org/topojson.v1.min.js"></script>
	<script type="text/javascript" src="/globe.js"></script>
	<script type="text/javascript" src="/minimap.js"></script>
</head>
<body>
	<script type="text/javascript">
	team_color = ["null","red","crimson","orange","peachpuff","yellow","lime","green","darkcyan","aqua","blue","mediumslateblue","navy","magenta","purple","indigo","pink"];
	var progress_list = [];
	var score_list = [];
	var team_object_list = [];
	var after_team_object_list = [];
	var font_size = 16/2;
	var width = 1500;
	var height = 700;
	// set d3 canvas
	arc = d3.arc()
		.innerRadius(40)
		.outerRadius(30)
		.startAngle(0);
	canvas = d3.select("body")
                .append("svg")
                .attr("width", width)
		.attr("height", height+y_base);
	var background = canvas.append("image")
		 .attr("xlink:href", "/space.gif")
		 .attr("x", 0)
		 .attr("y", 0)
		 .attr("width", "100%")
		 .attr("height", "100%");	
	class CircularProgress
	{
		constructor(targetX, targetY, team_num)
		{
			this.x = targetX;
			this.y = targetY;
			this.tau = 2 * Math.PI;
			this.g = canvas.append("g").attr("transform", "translate(" + this.x + "," + this.y + ")");
			this.background = this.g.append("path")
				.datum({endAngle: this.tau})
				.style("fill", "#ddd")
				.attr("d", arc);
			this.foreground = this.g.append("path")
				.datum({endAngle: 0.0 * this.tau})
				.style("fill", team_color[team_num])
				.attr("d", arc);
		}

		updateAngle(target_angle)
		{
			this.foreground.transition()
				.duration(750)
				.attrTween("d", this.arcTween(target_angle * this.tau));
		}

		movePath(targetX, targetY)
		{
			this.g.transition()
				.duration(2000)
				.attr("transform", "translate("+targetX+","+targetY+")");
		}

		setPos(targetX, targetY)
		{
			this.x = targetX;
			this.y = targetY;
		}

		arcTween( newAngle ) {
			return function(d) {
				var interpolate = d3.interpolate(d.endAngle, newAngle);
				return function(t)
				{
					d.endAngle = interpolate(t);
					return arc(d);
				}
			}
		}
	}
	// draw minimap
	draw_map();

	// draw rotating 3d globe
	var tmp = canvas.append("circle")
        .attr("stroke","#00248f")
        .attr("stroke-width",1)
        .attr("cx",680)
        .attr("cy",350)
        .attr("r",252)
	.attr("fill", "#00248f");
	 start_globe();
	// draw team information
	var team_num;
	var x_base = 1100;
	var y_base = 10;	
	for ( team_num = 0; team_num < 8; team_num++ )
	{
		var team_line = canvas.append("line")
			.style("stroke", team_color[team_num+1])
			.style("stroke-width", 6)
			.attr("x1", x_base+40)
			.attr("y1", y_base+40)
			.attr("x2", x_base+250)
			.attr("y2", y_base+40);
		var team_image = canvas.append("rect")
			.attr("x", x_base+210)
			.attr("y", y_base+50)
			.attr("width", 40)
			.attr("height", 25);
		var team_flag_rect = canvas.append("image")
			.attr("xlink:href", "http://35.238.139.0/img/"+team_array[team_num].tccode+".png")
			.attr("width", 40)
			.attr("height", 25)
			.attr("x", x_base+210)
			.attr("y", y_base+50);
		var cmt = team_array[team_num].tdescription;
		var magic = Math.floor(150/font_size);
		if ( cmt.length > magic )
		{
			cmt = cmt.substring(0, magic - 3) + " ...";
		}
		var team_comment = canvas.append("text")
			.attr("x", x_base+50 + ( ((150 - (150/magic)*cmt.length))/2 ))
			.attr("y", y_base+60)
			.text(cmt);
		var score = team_array[team_num].tscore;
		magic = Math.floor(80/17);
		var team_score = canvas.append("text")
			.attr("x", x_base-40 + ( ((80 - (80/magic)*score.length))/2 ))
			.attr("y", y_base+50)
			.style("font-size", "34px")
			.text(team_array[team_num].tscore);
		score_list.push(team_score);
			
		var name = team_array[team_num].tname;
		magic = Math.floor(210/font_size);
		if ( name.length > magic )
		{
			name = name.substring(0, magic - 3) + " ...";
		}
		var team_name = canvas.append("text")
			.attr("x", x_base+40 + ( ((210 - (210/magic)*name.length))/2 ))
			.attr("y", y_base+30)
			.text(team_array[team_num].tname);
		var progress = new CircularProgress(x_base, y_base+40, team_num+1);
		progress.updateAngle( team_array[team_num].tscore / 100 );
		progress_list.push(progress);

		var cur_team_object = new Object();
		cur_team_object.team_line = team_line;
		cur_team_object.team_flag_rect = team_flag_rect;
		cur_team_object.team_comment = team_comment;
		cur_team_object.team_score = team_score;
		cur_team_object.team_image = team_image;
		cur_team_object.team_name = team_name;
		cur_team_object.progress = progress;
		team_object_list.push(cur_team_object);
		after_team_object_list.push(cur_team_object);
		y_base += 87.5;
	}
	function ajaxQuery()
	{
		function reqListener () 
		{
			var after_list = JSON.parse(this.responseText);
			var target_index_list = new Array();
			var tmp_y_pos = new Array();
			/*
			for ( var i = 0; i < 8; i++ )
			{
				document.write(team_object_list[i].progress.y+" ");
			}
			document.write("</br>");
			 */
			for ( var i = 0; i < 8; i++ )
				for ( var j = 0; j < 8; j++ )
				{
					if ( team_array[i].tname == after_list[j].tname )
					{
						target_index_list.push(j);
						team_array[i].tscore = after_list[j].tscore;
						team_array[i].tdescription = after_list[j].tdescription;
					}
				}
			for ( var i = 0; i < 8; i++ )
			{
				// move team_line
				var target_y = team_object_list[ target_index_list[i] ].team_line.attr("y1");
				team_object_list[i].team_line.transition().duration(2000).attr("y1", target_y).attr("y2", target_y);
				// move team_flag_rect
				var target_y = team_object_list[ target_index_list[i] ].team_flag_rect.attr("y");
				team_object_list[i].team_flag_rect.transition().duration(2000).attr("y", target_y);
				// move team_comment
				var target_y = team_object_list[ target_index_list[i] ].team_comment.attr("y");
				team_object_list[i].team_comment.transition().duration(2000).attr("y", target_y);
				// move team_score
				var target_y = team_object_list[ target_index_list[i] ].team_score.attr("y");
				team_object_list[i].team_score.transition().duration(2000).attr("y", target_y);
				// update team_score
				var magic_var = Math.floor(80/17);	
				team_object_list[i].team_score
				.attr("x", x_base-40 + ( ((80 - (80/magic_var)*team_array[i].tscore.length))/2 ))
				.text(team_array[i].tscore);
				// move team_image
				var target_y = team_object_list[ target_index_list[i] ].team_image.attr("y");
				team_object_list[i].team_image.transition().duration(2000).attr("y", target_y);
				// move team_name
				var target_y = team_object_list[ target_index_list[i] ].team_name.attr("y");
				team_object_list[i].team_name.transition().duration(2000).attr("y", target_y);
				// move progress and update angle
				var target_y = team_object_list[ target_index_list[i] ].progress.y;
				team_object_list[i].progress.updateAngle( team_array[i].tscore / 100 );
				team_object_list[i].progress.movePath(x_base, target_y);
				tmp_y_pos.push(team_object_list[i].progress.y);
			}
			for ( var i = 0; i < 8; i++ )
				team_object_list[i].progress.setPos(x_base, tmp_y_pos[ target_index_list[i] ]);
			
			for ( var i = 0; i < 8; i++ )
				for ( var j = 0; j < 8; j++ )
					if ( team_array[i].tname == after_list[j].tname )
					{
						after_team_object_list[j] = team_object_list[i];
						after_team_array[j] = team_array[i];
					}
			for ( var i = 0; i < 8; i++ )
			{
				team_object_list[i] = after_team_object_list[i];
				team_array[i] = after_team_array[i];
			}
			/*
			var obj = JSON.parse(this.responseText);
			var idx;
			for ( idx=0; idx<8; idx++ )
			{
				progress_list[idx].updateAngle(obj[idx].tscore/100);
				var target = score_list[idx];
				var tscore = obj[idx].tscore;
				var magic_var = Math.floor(80/17);	
				target
				.attr("x", x_base-40 + ( ((80 - (80/magic_var)*tscore.length))/2 ))
				.text(tscore);
			}*/
		}

		var oReq = new XMLHttpRequest();
		oReq.addEventListener("load", reqListener);
		oReq.open("GET", "http://35.238.139.0/query_teaminfo.php");
		oReq.send();
	}
	function test()
	{
		document.write("test write");
	}
	setInterval(ajaxQuery, 30000);
    </script>
</body>
</html>
