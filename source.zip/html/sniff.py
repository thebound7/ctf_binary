import pymysql
import os
from scapy.all import *

os.system("rm -r ./packets")
os.system("mkdir ./packets")

conn = pymysql.connect(host='localhost', user='root', password='toor', db='ctfv', charset='utf8')

curs = conn.cursor()
curs.execute('select tid, tname, tport from team')
raws = curs.fetchall()

for raw in raws:
    tid, tname, tport = raw
    os.system("mkdir ./packets/"+str(tid))

# start sniff docker0
idx = 0
while True:
    pkts_array = []
    for raw in raws:
        tid, tname, tport = raw
        pkts_array.append([])
    # log 60 seconds
    pkts = sniff(count=1, iface='docker0')
    for pkt in pkts:
        tidx = 0
        for raw in raws:
            tid, tname, tport = raw
            try:
                if tport == pkt.dport or tport == pkt.sport:
                    pkts_array[tidx].append(pkt)
            except:
                tidx += 1
                continue
            tidx += 1
    tidx = 0
    for raw in raws:
        tid, tname, tport = raw
        if len(pkts_array[tidx]) != 0:
            wrpcap("./packets/"+str(tid)+"/"+str(idx)+"", pkts_array[tidx])
    idx += 1
