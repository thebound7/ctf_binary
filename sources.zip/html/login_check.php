<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
session_start();
include 'database.php';
$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT username, password FROM user WHERE username = '$username' and password = '$password'";
$result = $conn->query($query);

if ( $result->num_rows > 0 )
{
	$row = mysqli_fetch_assoc($result);
	$_SESSION['userid'] = $row['username'];
	echo "<script>alert('Login Success');";
	echo "window.location.href='./index.php'</script>";
}
else
{
	echo "<script>alert('Wrong User Information');";
	echo "window.location.href='./index.php'</script>";
}
?>
