<?php
	$conn = mysqli_connect("localhost", "root", "toor", "gallery");
?>
