<?php
if ( isset($_GET['ip']) )
{
	$ip = $_GET['ip'];
	if ( $_SERVER['REMOTE_ADDR'] == '127.0.0.1' or $_SERVER['REMOTE_ADDR'] == '::1' )
	{
		system('ping '.$ip.' -c 1');
	}
	else
	{
		echo "<script>alert('You must request from localhost!');";
		echo "window.location.href='./index.php';</script>";
		exit;
	}
}
?>
