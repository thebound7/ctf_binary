<?php
if(isset($_GET["file"]) and isset($_GET["key"])){
	$file = $_GET["file"];
	$key = $_REQUEST["key"];
	$filepath = "images/" . $file;

	$hashed = hash("sha256", $file);

	if(file_exists($filepath) and strtoupper($hashed) === strtoupper($key)) {
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length: ' . filesize($filepath));
		flush();
		readfile($filepath);
		exit;
	}
}
?>
