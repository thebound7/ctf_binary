<?php
session_start();
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["dcxml"]["name"]);
$uploadOk = 1;
$file_type = strtolower( pathinfo($target_file,PATHINFO_EXTENSION) );
if ( file_exists($target_file) ) 
{
	$uploadOk = 0;
}
if ( $_FILES["dcxml"]["size"] > 500000 ) 
{
	$uploadOk = 0;
}
if ( $file_type != "xml" )
{
	$uploadOk = 0;
}
if ( $_SESSION['userid'] !== 'admin' )
{
	$uploadOk = 0;
}
if ( $uploadOk == 0 ) 
{
	echo "<script>alert('You can not upload this file!');";
	echo "window.location.href='./index.php';</script>";
	exit;
} 
else 
{
	if ( move_uploaded_file($_FILES["dcxml"]["tmp_name"], $target_file) ) 
	{
		#echo "The file ". basename( $_FILES["dcxml"]["name"]). " has been uploaded.";
		
		$content = file_get_contents('http://localhost/'.$target_file);
		if ( $content !== false )
		{
			$root = simplexml_load_string($content, 'SimpleXMLElement', LIBXML_NOENT);
			$dc_name = $root->dc->title;
			if ( $dc_name != "Nude Descending Stair" )
			{
				echo "<h1>Invalid Duchamp Information File !!</h1>";
				echo $dc_name;
			}
			else
			{
				$dc_data = $root->dc->data;
				echo "<h1>$dc_name</h1>";
				echo $dc_data;
			}
		}

		if ( !unlink($target_file) )
		{
			echo "<script>alert('Error occured!\nPlease contact admin.');";
			echo "window.location.href='./index.php';</script>";
			exit;
		}
		
	} 
	else 
	{
		echo "<script>alert('Some problems occur while uploading file!');";
		echo "window.location.href='./index.php';</script>";
		exit;
	}
}
?>
