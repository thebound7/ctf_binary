<?php session_start(); ?>
<html>
<head>
	<title>Marcel Duchamp Gallery</title>
	<link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<div class="container" style="display: inline-block;text-align: center;">
<?php
if ( !isset($_SESSION['userid']) )
{
	header( 'Location: ./login.php' );
}
?>
<h1>Welcome <?php echo ''.$_SESSION['userid']; ?> !!</h1>
<?php
if ( $_SESSION['userid'] !== 'admin' )
{
	echo "<h1>Today Picture</h1>";
	echo "<h1>Marcel Duchamp Nude Descending Stair</h1>";
	echo "<p><img src='./images/descending.jpg'></p>";
	echo "<p><a href=download.php?file=descending.jpg&key=216fc254df63732b9f954af45515a358ae829502b6d50867145ece03a0fae5ed>download</a></p>";
}
else
{
	echo "<br />";
	echo "<br />";
	echo "<form action='check_dc.php' method='post' enctype='multipart/form-data'>";
	echo "<h1>Check Validity</h1>";
	echo "<p><input type='file' name='dcxml'>";
	echo "<input type='submit' value='Check'></p>";
	echo "</form>";

	echo "<br />";
	echo "<br />";

	echo "<h1>Check Connection</h1>";
	echo "<a href='check_connect.php?ip=8.8.8.8'>Check</a>";

	echo "<br />";
	echo "<br />";
}
?>
<p><a href='./logout.php'>logout</a></p>
</div>
</body>
</html>
